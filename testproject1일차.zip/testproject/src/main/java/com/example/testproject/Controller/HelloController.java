package com.example.testproject.Controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class HelloController {

    @GetMapping("/hi")
    public String Hello(Model model){
        model.addAttribute("username","태웅");
        model.addAttribute("username2","태웅2");
        return "hello";
    }
    @GetMapping("/tt")
    public String home(){
        return "home";
    }
}
